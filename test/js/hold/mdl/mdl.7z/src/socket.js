/*
var socket;

socket = new io.Socket('http://192.168.10.13', {
	port: 3000
});
socket.connect(); 


socket.on('connect', function () {
	console.log('Client has connected to the server!');
});


socket.on('message', function (data) {
	console.log('Received a message from the server!', data);
});


socket.on('disconnect', function () {
	console.log('The client has disconnected!');
});


function sendMessageToServer(message) {
	socket.send(message);
}
*/

