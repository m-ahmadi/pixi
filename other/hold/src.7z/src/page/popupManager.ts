var popupManager: any = {};


function create() {

}

function remove() {

}